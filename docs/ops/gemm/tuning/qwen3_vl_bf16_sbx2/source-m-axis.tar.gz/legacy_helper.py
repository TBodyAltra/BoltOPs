# Copyright (c) 2026 Hygon Information Technology Co., Ltd.
# SPDX-License-Identifier: MIT
"""Complete-tile BF16 TN GEMM with a configurable 1P+1C MLS ring.

CHUNKS sets the BK128 operand pairs per slot; SLOTS sets the ring depth. The consumer finishes both DS
reads before releasing the slot and overlaps the last MMAC with its refill.
A is row-contiguous [M,K]; logical B has strides (1,K), sharing storage with
public row-contiguous W[N,K]. The complete K is accumulated in FP32.
"""
from triton.experimental import gluon as g
from triton.experimental.gluon import language as gl
from triton.experimental.gluon.language.amd.cdna4 import async_copy
from triton.experimental.gluon.language.amd.hcu import (
    MlsSharedLayout, MmacLayout, matrix_load, wait_lgkmcnt, sched_barrier,
    abarrier_init, abarrier_arrive, abarrier_seq, abarrier_try_wait,
    ebarrier_sync, get_wave_id,
)


@g.jit
def _idle_partition():
    pass


@g.jit
def _load_mls_batch(A, B, sa, sb, om, on, start,
                    M: gl.constexpr, N: gl.constexpr, K: gl.constexpr,
                    BK: gl.constexpr, CHUNKS: gl.constexpr, PW: gl.constexpr, TN: gl.constexpr):
    for i in gl.static_range(CHUNKS):
        matrix_load(sa[i], A, (M, K), (K, 1),
                    (om, (start + i) * BK), warps=(PW, 1))
        matrix_load(sb[i], B, (K, N), (1, K) if TN else (N, 1),
                    ((start + i) * BK, on), warps=(1, PW))


@g.jit
def _mls_producer(A, B, aa, bb,
                  M: gl.constexpr, N: gl.constexpr, K: gl.constexpr,
                  BM: gl.constexpr, BN: gl.constexpr, BK: gl.constexpr,
                  CHUNKS: gl.constexpr, SLOTS: gl.constexpr,
                  PW: gl.constexpr, CW: gl.constexpr, TN: gl.constexpr):
    # One physical wave initializes all EMPTY/READY pairs. Every consumer
    # releases one EMPTY arrival; every producer contributes one READY arrival.
    if get_wave_id() == 0:
        for s in gl.static_range(SLOTS):
            abarrier_init(s * 2, CW)
            abarrier_init(s * 2 + 1, PW)
            abarrier_arrive(s * 2, CW)
    ebarrier_sync(0, PW + CW)
    pid = gl.program_id(0)
    om, on = (pid // (N // BN)) * BM, (pid % (N // BN)) * BN
    for batch in gl.static_range(K // (BK * CHUNKS)):
        # Keep tuple subscripts as compile-time expressions: assigning this
        # remainder to an ordinary local would turn it into a tensor index.
        abarrier_try_wait((batch % SLOTS) * 2, (batch // SLOTS) % 2)
        abarrier_seq((batch % SLOTS) * 2 + 1)
        _load_mls_batch(A, B, aa[batch % SLOTS], bb[batch % SLOTS], om, on,
                        batch * CHUNKS, M, N, K, BK, CHUNKS, PW, TN)
        abarrier_arrive((batch % SLOTS) * 2 + 1)
    ebarrier_sync(15, PW + CW)


@g.jit
def _consume_mls_batch(sa, sb, acc, F: gl.constexpr,
                       CHUNKS: gl.constexpr, release: gl.constexpr, WAIT: gl.constexpr):
    xx, yy = (), ()
    for i in gl.static_range(CHUNKS):
        xx += (async_copy.load_shared_relaxed(sa[i], gl.DotOperandLayout(0, F, 4)),)
        yy += (async_copy.load_shared_relaxed(sb[i], gl.DotOperandLayout(1, F, 4)),)
    sched_barrier(0)
    for i in gl.static_range(CHUNKS):
        if WAIT == 1:
            wait_lgkmcnt(15 if i < CHUNKS - 2 else (8 if i == CHUNKS - 2 else 0))
        if i == CHUNKS - 1:
            # All DS reads must finish before the producer reuses this slot.
            # The last MMAC can overlap that refill because operands are VGPRs.
            wait_lgkmcnt(0)
            abarrier_arrive(release)
        sched_barrier(0)
        acc = gl.amd.cdna4.mfma(xx[i], yy[i], acc)
        sched_barrier(0)
    return acc


@g.jit
def _mmac_consumer(C, aa, bb, F: gl.constexpr,
                   M: gl.constexpr, N: gl.constexpr, K: gl.constexpr,
                   BM: gl.constexpr, BN: gl.constexpr, BK: gl.constexpr,
                   CHUNKS: gl.constexpr, SLOTS: gl.constexpr,
                   PW: gl.constexpr, CW: gl.constexpr, WAIT: gl.constexpr):
    ebarrier_sync(0, PW + CW)
    pid = gl.program_id(0)
    om, on = (pid // (N // BN)) * BM, (pid % (N // BN)) * BN
    acc = gl.full((BM, BN), 0, gl.float32, F)
    for batch in gl.static_range(K // (BK * CHUNKS)):
        abarrier_try_wait((batch % SLOTS) * 2 + 1, (batch // SLOTS) % 2)
        acc = _consume_mls_batch(aa[batch % SLOTS], bb[batch % SLOTS], acc,
                                 F, CHUNKS, (batch % SLOTS) * 2, WAIT)
    rows = om + gl.arange(0, BM, layout=gl.SliceLayout(1, F))
    cols = on + gl.arange(0, BN, layout=gl.SliceLayout(0, F))
    gl.amd.cdna3.buffer_store(acc.to(gl.bfloat16), C,
                             rows[:, None] * N + cols[None, :])
    ebarrier_sync(15, PW + CW)


@g.jit
def gemm_a16w16_tn_kernel(
    A, B, C, M: gl.constexpr, N: gl.constexpr, K: gl.constexpr,
    BLOCK_SIZE_M: gl.constexpr = 16, BLOCK_SIZE_N: gl.constexpr = 16,
    BLOCK_SIZE_K: gl.constexpr = 128, B_K_CONTIGUOUS: gl.constexpr = True,
    LOOP_UNROLL_FACTOR: gl.constexpr = 4,
    CHUNKS: gl.constexpr = 4, SLOTS: gl.constexpr = 2,
):
    gl.static_assert(B_K_CONTIGUOUS, "this pipeline requires TN weights")
    gl.static_assert(M % BLOCK_SIZE_M == 0 and N % BLOCK_SIZE_N == 0)
    gl.static_assert((CHUNKS == 1 or CHUNKS == 2 or CHUNKS == 4) and SLOTS >= 1 and SLOTS <= 4)
    gl.static_assert(K % (BLOCK_SIZE_K * CHUNKS) == 0)
    gl.static_assert(LOOP_UNROLL_FACTOR == 4)
    gl.static_assert((BLOCK_SIZE_M, BLOCK_SIZE_N, BLOCK_SIZE_K) == (16, 16, 128))
    gl.static_assert(A.dtype.element_ty == gl.bfloat16 and
                     B.dtype.element_ty == gl.bfloat16 and
                     C.dtype.element_ty == gl.bfloat16)
    BM: gl.constexpr = BLOCK_SIZE_M
    BN: gl.constexpr = BLOCK_SIZE_N
    BK: gl.constexpr = BLOCK_SIZE_K
    F: gl.constexpr = gl.amd.AMDMFMALayout(
        version=4, instr_shape=[16, 16, 16], mmac_layout=MmacLayout.LIT,
        warps_per_cta=[1, 1], tiles_per_warp=[1, 1],
    )
    SA: gl.constexpr = MlsSharedLayout(0, (16, 32), bits=16, order=(1, 0))
    SB: gl.constexpr = MlsSharedLayout(1, (32, 16), bits=16, order=(0, 1))
    aa, bb = (), ()
    for slot in gl.static_range(SLOTS):
        sa, sb = (), ()
        for i in gl.static_range(CHUNKS):
            sa += (gl.allocate_shared_memory(gl.bfloat16, (BM, BK), SA),)
            sb += (gl.allocate_shared_memory(gl.bfloat16, (BK, BN), SB),)
        aa += (sa,)
        bb += (sb,)
    gl.warp_specialize([
        (_idle_partition, ()),
        (_mls_producer, (A, B, aa, bb, M, N, K, BM, BN, BK, CHUNKS, SLOTS, 1, 1, True)),
        (_mmac_consumer, (C, aa, bb, F, M, N, K, BM, BN, BK, CHUNKS, SLOTS, 1, 1, 1)),
    ], [1, 1], [48, 240])
